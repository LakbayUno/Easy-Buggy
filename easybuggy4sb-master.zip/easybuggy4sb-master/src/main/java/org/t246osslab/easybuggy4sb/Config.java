package org.t246osslab.easybuggy4sb;

public class Config {
    public static final String APP_ROOT = "/eb/v1";
    public static final String TEMPLATE_PREFIX = "eb/v1/";
    public static final String AUTH_USER = "user1";
    public static final String AUTH_PASS = "pass2";
}
